a=zeros(1,30);
for function_number=1:30
    
thisfilename = sprintf('results%d', function_number);
load(thisfilename)
a(function_number)=mean([results.FVr_oa]);

end
a=a';