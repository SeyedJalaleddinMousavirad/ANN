function S_MSE = funcmat(agent,function_number)

fhd=str2func('cec17_func');
S_MSE.I_nc      = 0;%no constraints
S_MSE.FVr_ca    = 0;%no constraint array
S_MSE.I_no      = 1;%number of objectives (costs)
%  S_MSE.FVr_oa(1) = feval(fname,agent',function_number);
if(size(agent,1)<=1)
    agent=agent';
end
varargin=num2cell(function_number);
S_MSE.FVr_oa(1) =cec17_func(agent,varargin{:});
% S_MSE.FVr_oa(1) = benchmark_func(agent',function_number);
end