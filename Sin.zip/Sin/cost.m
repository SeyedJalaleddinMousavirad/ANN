function S_MSE=cost(x)
 
global net;
global train_dataset_input;
global train_dataset_output;
global test_dataset_input;
global test_dataset_output;


  net=setwb(net,x);  
  
%   out=sim(net,test_dataset_input);
  out=net(train_dataset_input);
%  net.trainFcn = 'traingd';
%  net.trainParam.lr=0.005;
 z=mse(out,train_dataset_output);
%    z=mean((out-train_dataset_output).^2);
%    out=vec2ind(out);
%    train_dataset_output=vec2ind(train_dataset_output);
%   test_dataset_output=vec2ind(test_dataset_output);
%   z= sum((out-test_dataset_output).^2)/length(out);
  S_MSE.I_nc      = 0;%no constraints
S_MSE.FVr_ca    = 0;%no constraint array
S_MSE.I_no      = 1;%number of objectives (costs)
S_MSE.FVr_oa(1) = z;
 
 













